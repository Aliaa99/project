<!--##################### footer ##################-->


        <!-- Jquery js -->
        <script src="js/jquery-3.2.1.js"></script>
        <!-- Bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.carousel.js"></script>
    <script src="js/lightbox.js"></script>
    <script type="text/javascript" src="js/main.js"></script>

</body>
</html>