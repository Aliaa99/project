////menu

//menu

$(document).ready(function(){
    $('.main .op').click(function(){
        $('.menu2').css({"width":"60%",})
        $('.main').css({"left":"40%",})
        $(this).toggle();
        $('.main span').toggle();

    });
    $('.menu2 .clo').click(function(){
        $(this).parent().css({"width":"0",})
        $('.main').css({"left":"0",})
        $('.main .op').toggle();
        $('.main span').toggle();
    });
        $('.opop').click(function(){
        $('.men').slideToggle();
    });
    $('.searchinput').click(function(){
          $('.serchtoggle').toggle(500);
            $(this).toggle(500);
       });
//    $('.serchtoggle::after').click(function(){
//          $('#demo').toggle(500);
//       });

});

//
//                    //scroll top
//
//$('.bottom-nav a').click (function(){
//      $('html,body').animate({
//          scrollTop:$("#down").offset().top},1000);
//   });
//    
//
//
//
//
$('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    rtl:true,
    dots:false,
    autoplay:true,
    autoplayTimeout:5000,
    responsive:{
        0:{
            items:1
        }
    }
});

    //fancy box
    $('.various').fancybox({
        padding : 10,
        openEffect  : 'fade'
    });

    



