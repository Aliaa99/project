<!DOCTYPE html>
<html lang="en">
<head>
  <title>web-page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/font-awesome.min.css" />

         <!-- Bootstrap Css -->
      <link rel="stylesheet" href="css/bootstrap-e.min.css" />
      <link rel="stylesheet" href="css/bootstrap-a.min.css" />
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="css/owl.carousel.min.css">
      <link rel="stylesheet" href="css/owl.theme.default.min.css">
      <link rel="stylesheet" href="css/animate.min.css">
      <link rel="stylesheet" href="css/lightbox.css">
      <link rel="shortcut icon" href="images/logo.png">
      <link rel="stylesheet" href="css/main.css">
      <link rel="stylesheet" href="css/stylesheet.css">

</head>
<body>

<header>
   <div class="navpro">
    <div class="upnav">
       <div class="container">
         <div class="row">
               <div class="col-lg-8 col-sm-6">
                    <ul>
                       <li><a href="#">إنهاء الطلب</a></li>
                       <li><a href="#">قائمة رغباتى</a></li>
                       <li><a href="#">تتبع الطلب</a></li>
                       <li  class="language">
                           <span>اللغة :</span>
                              <select class="form-control" id="sel1">
                                <option>العربي</option>
                                <option>العربي</option>
                              </select>
                        </li>
                   </ul>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <ul class="direct">
                       <li><a href="#">تسجيل دخول</a></li>
                       <li><a href="#" class="newregister">تسجيل جديد</a></li>
                       <li><a href="#" class="members">إنضم لتجارنا</a></li>
                    </ul>
                </div>
            </div>
         </div>
    </div>
       
       
<!--       nav bar  -->
    <div class="headnavbar">
       <div class="container">
         <div class="navdiv1">
             <div class="row">
                   <div class="col-sm-2">
                        <img src="images/logo.png">
                    </div>
            <div class="col-lg-7 col-lg-offset3 col-md-6 ">
            <div  class="serchtoggle" >                 
               <input class="btn"placeholder="أبحث">
                <a href="#demo"  data-toggle="collapse" class="downlistcheck"><i class="fa fa-chevron-down" aria-hidden="true"></i></a>
                 <div id="demo" class="collapse">
                    <form>
                        <div class="itemcheck all">
                          <input type="checkbox">
                           <label>عرض الكل</label>
                        </div>
                        <div class="itemcheck">
                          <input type="checkbox">
                           <label>عرض الأحداث</label>
                        </div>
                        <div class="itemcheck">
                          <input type="checkbox">
                           <label>عرض الأكثر شعبية</label>
                        </div>
                        <div class="itemcheck">
                          <input type="checkbox">
                           <label class="price">
                               <a href="#demo2" data-toggle="collapse">عرض بالسعر
                               <a href="#demo2" data-toggle="collapse" class="downlistcheck listradio" aria-expanded="true"><i class="fa fa-chevron-down" aria-hidden="true"></i></a>
                               </a>
                           </label>
                        </div>
                           <div id="demo2" class="collapse">
                            <div class="itemcheck">
                              <input type="radio" name="xx">
                               <label>بالأقل سعر</label>
                            </div>
                            <div class="itemcheck">
                              <input type="radio" name="xx">
                               <label>بالأكثر سعر</label>
                            </div>
                           </div>
                      </form>
                     </div>
                   </div>
                        <a href="#" class="searchinput"><i class="fa fa-search" aria-hidden="true"></i></a>
                 </div>
                    <div class="col-lg-3 col-md-4">
                        <div class="buy">
                          <a href="#"><i class="fa fa-shopping-basket" aria-hidden="true"></i></a>
                            <span class="bord">2<span>منتجاتك</span></span>
                            <span>RS<span>209</span></span>
                        </div>
                    </div>
                 </div>
            </div>
           <div class="navbarlist">
               <div class="row">
                   <div class="col-sm-10 col-sm-offset-2">
                   <ul> 
                      <li class="active">
                          <a href="#">الرئيسية</a>
                       </li>
                      <li>
                          <a href="#">أنواع البطاقات</a>
                       </li>
                      <li>
                          <a href="#">الأكسسورات</a>
                             <div class="listofall">
                                <ul>
                                   <li><a href="#">الاكسسورات</a></li>
                                   <li><a href="#">الاكسسورات</a></li>
                                   <li><a href="#">الاكسسورات</a></li>
                              </ul>
                            </div>
                       </li>
                      <li>
                          <a href="#">مشتريات الجوال</a>
                       </li>
                      <li>
                          <a href="#">قسم الألعاب</a>
                       </li>
                      <li>
                          <a href="#">تأكيد الحوالة البنكية</a>
                       </li>
                      <li>
                          <a href="#">معلومات </a>
                       </li>
                      <li>
                          <a href="#">إتصل بنا</a>
                       </li>
                    </ul>
                </div>
             </div>
           </div>
         </div>
     </div>
   </div>

</header>
<div class="sidemen" >
      <div class="side-nav">
        <div class="main">
          <a href="#side-list" class="op"><i class="fa fa-bars" aria-hidden="true"></i></a>
          <a href="#"><img src="images/logo.png"></a>
        </div>
        <div class="menu2 animated fadeInRight" id="side-list">
          <a href="#side-list" class="clo"><i class="fa fa-times" aria-hidden="true"></i></a>
                   <ul> 
                      <li class="active">
                          <a href="#">الرئيسية</a>
                       </li>
                      <li>
                          <a href="#">أنواع البطاقات</a>
                       </li>
                      <li>
                          <a href="#">الأكسسورات</a>
                       </li>
                      <li>
                          <a href="#">مشتريات الجوال</a>
                       </li>
                      <li>
                          <a href="#">قسم الألعاب</a>
                       </li>
                      <li>
                          <a href="#">تأكيد الحوالة البنكية</a>
                       </li>
                      <li>
                          <a href="#">معلومات </a>
                       </li>
                      <li>
                          <a href="#">إتصل بنا</a>
                       </li>
                    </ul>
        </div>
    </div>
         

    </div>